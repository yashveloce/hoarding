import React from 'react'

export default function Franchise_Management() {
    return (
        <div>
            
        </div>
    )
}
